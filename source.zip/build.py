# Builds a flat, upload-friendly copy in dist/ (9 files, no folders) for GitHub Pages.
# Usage: python3 build.py   (needs esbuild: npx esbuild)
import os, json, base64, hashlib, shutil, subprocess, glob
root=os.path.dirname(os.path.abspath(__file__)); dist=os.path.join(root,'dist')
shutil.rmtree(dist, ignore_errors=True); os.makedirs(dist)
esb = os.environ.get('ESBUILD','npx --yes esbuild@0.24.0')
subprocess.check_call(f"{esb} js/app.js --bundle --format=esm --minify --outfile=dist/app.js --log-level=warning", shell=True, cwd=root)
data={}
for p in sorted(glob.glob(os.path.join(root,'img','*','*.jpg'))):
    id_=os.path.basename(os.path.dirname(p)); n=os.path.splitext(os.path.basename(p))[0]
    data[f'{id_}/{n}']='data:image/jpeg;base64,'+base64.b64encode(open(p,'rb').read()).decode()
open(os.path.join(dist,'img.js'),'w').write('window.IMGDATA='+json.dumps(data,separators=(',',':'))+';')
shutil.copy(os.path.join(root,'styles.css'), dist)
for f in glob.glob(os.path.join(root,'icons','*.png')): shutil.copy(f, dist)
m=open(os.path.join(root,'manifest.webmanifest')).read().replace('icons/',''); open(os.path.join(dist,'manifest.webmanifest'),'w').write(m)
h=open(os.path.join(root,'index.html')).read().replace('icons/','').replace('<script type="module" src="js/app.js"></script>','<script src="img.js"></script>\n<script type="module" src="app.js"></script>')
open(os.path.join(dist,'index.html'),'w').write(h)
files=sorted(os.listdir(dist)); hh=hashlib.sha1()
for f in files: hh.update(open(os.path.join(dist,f),'rb').read())
ver=hh.hexdigest()[:10]
open(os.path.join(dist,'sw.js'),'w').write(f"""const CACHE='move-{ver}';
const FILES={json.dumps(['./']+files)};
self.addEventListener('install',e=>{{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()));}});
self.addEventListener('activate',e=>{{e.waitUntil((async()=>{{for(const k of await caches.keys()) if(k!==CACHE) await caches.delete(k); await self.clients.claim();}})());}});
self.addEventListener('fetch',e=>{{if(e.request.method!=='GET')return; e.respondWith((async()=>{{const c=await caches.open(CACHE); const hit=await c.match(e.request,{{ignoreSearch:true}}); if(hit)return hit; try{{return await fetch(e.request);}}catch(err){{return (await c.match('./'))||Response.error();}}}})());}});
""")
print('dist', ver, {f: os.path.getsize(os.path.join(dist,f)) for f in os.listdir(dist)})
