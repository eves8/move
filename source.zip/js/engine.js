// Workout generator: balanced full-body sessions, 4-week goal-based blocks.
import { EXERCISES, BY_KEY } from './exercises.js';

export const PATTERNS = ['hpush','vpush','hpull','vpull','squat','lunge','hinge','glute','coreA','coreR','coreL','coreF','cardio','bi','tri'];
export const PATTERN_LABEL = {hpush:'Push',vpush:'Shoulders',hpull:'Back/row',vpull:'Pull/lats',squat:'Squat',lunge:'Lunge',hinge:'Hinge',glute:'Glutes',coreA:'Core',coreR:'Obliques',coreL:'Side core',coreF:'Lower abs',cardio:'Cardio',bi:'Biceps',tri:'Triceps'};

export const DEFAULT_LEVELS = {hpush:2.3,vpush:2.2,hpull:2.5,vpull:2.5,squat:2.6,lunge:2.4,hinge:2.4,glute:2.5,coreA:2.6,coreR:2.4,coreL:2.4,coreF:2.4,cardio:2.4,bi:2,tri:2};

// Block phases (by workouts done, not calendar days)
export const PHASES = [
  {name:'Base',  work:40, rest:20, lvl:0,    rep:1.0},
  {name:'Build', work:45, rest:15, lvl:0.4,  rep:1.1},
  {name:'Push',  work:45, rest:15, lvl:0.8,  rep:1.2},
  {name:'Lighter',work:35,rest:25, lvl:-0.3, rep:0.9},
];
const INTENSITY = {hard:{lvl:0.4,work:5,rest:-5}, medium:{lvl:0,work:0,rest:0}, light:{lvl:-0.7,work:-10,rest:10}};
const INT_CYCLE = ['hard','medium','light'];
const EMPH_CYCLE = ['push','legs','pull','core'];
export const EMPH_LABEL = {push:'Upper push',legs:'Legs & glutes',pull:'Back & posture',core:'Core & conditioning',mobility:'Mobility'};

const rnd = () => Math.random();
const pick = a => a[Math.floor(rnd()*a.length)];
const shuffle = a => { a=[...a]; for(let i=a.length-1;i>0;i--){const j=Math.floor(rnd()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; };
const today = () => new Date().toISOString().slice(0,10);
const r5 = s => Math.max(10, Math.round(s/5)*5);

export function phaseFor(state){
  const b = state.block; const per = b.goal/4;
  const w = Math.min(3, Math.floor(b.done / per));
  return {week:w+1, ...PHASES[w]};
}

// Count of each pattern done in the last 7 days (for balance)
function weeklyCounts(state){
  const since = Date.now() - 7*864e5; const c = Object.fromEntries(PATTERNS.map(p=>[p,0]));
  for(const h of state.history) if(h.ts>=since && h.pat) for(const [p,n] of Object.entries(h.pat)) c[p]=(c[p]||0)+n;
  return c;
}
function recentSet(state, n=3){
  const s=new Set(); for(const h of state.history.slice(-n)) (h.exs||[]).forEach(k=>s.add(k)); return s;
}

function dbWeight(state, cls, week){
  const ws=[...(state.settings.dbWeights||[2,3,4,5])].sort((a,b)=>a-b); if(!ws.length) return null;
  let i = cls==='L'? Math.floor((ws.length-1)*0.25) : cls==='M'? Math.round((ws.length-1)*0.6) : ws.length-1;
  if(week>=2 && cls!=='H') i=Math.min(ws.length-1,i+1);
  return ws[i];
}

const isBlocked = (state, k) => (state.settings.blocked||[]).includes(k);

// Choose one exercise.
function choose(ctx, {patterns, role, eq, target, maxLvl, noSide}){
  const {state, used, recent} = ctx; const quiet = state.settings.quiet;
  let cands = EXERCISES.filter(x => patterns.includes(x.p) && x.r.includes(role) && !used.has(x.k)
    && ctx.allowedEq.has(x.e) && (ctx.gym || !x.k.startsWith('g_')) && (!eq || x.e===eq) && !(quiet && x.f.includes('J')) && !(state.settings.backCare && /[NB]/.test(x.f)) && !(noSide && x.f.includes('S')) && !isBlocked(state, x.k));
  if(maxLvl!=null) cands = cands.filter(x=>x.l<=maxLvl);
  // never far above the target level
  const capped = cands.filter(x=>x.l <= target + 1.0);
  if(capped.length) cands = capped;
  if(!cands.length) return null;
  const scored = cands.map(x=>({x, s: -Math.abs(x.l-target)*1.1 + rnd()*1.3 - (recent.has(x.k)?3:0)}));
  scored.sort((a,b)=>b.s-a.s);
  const ex = scored[0].x; used.add(ex.k); return ex;
}

function lvlTarget(ctx, p, wave=0){
  return (ctx.state.levels[p] ?? 2.5) + ctx.phase.lvl + ctx.inten.lvl + (ctx.state.effort||0)*0.25 + wave;
}

function workStep(ctx, ex, work, opts={}){
  if(ex.f.includes('H') && ex.x && work) work = Math.min(work, ex.x);
  const reps = (ex.x && !ex.f.includes('H')) ? Math.max(4, Math.round(ex.x * ctx.phase.rep * (ctx.intensity==='light'?0.85:1))) : 0;
  let cls = ex.w||'M';
  if(ctx.state.settings.backCare && cls==='H' && ['hinge','hpull','vpull'].includes(ex.p)) cls='M';
  let weight = ex.e==='d' ? dbWeight(ctx.state, cls, ctx.phase.week) : null;
  if(opts.ramp && weight){ const ws=[...ctx.state.settings.dbWeights].sort((a,b)=>a-b); const lower=ws.filter(w=>w<weight); if(lower.length) weight=lower[lower.length-1]; }
  ctx.exs.add(ex.k);
  return {t:'work', ex:ex.k, dur:work, reps, weight, ...opts};
}

// Equipment mix-in: decide which strength/finisher slots use which equipment.
function equipmentPlan(state, slots){
  // slots: array of {patterns, role}
  const mix = state.settings.mix; const n = slots.length; const assign = new Array(n).fill(null);
  const order = [['g', {little:2, balanced:Math.round(n*0.4), focus:Math.round(n*0.6)}],
                 ['p', {little:2, balanced:Math.round(n*0.3), focus:Math.round(n*0.5)}],
                 ['d', {little:3, balanced:Math.round(n*0.35), focus:Math.round(n*0.55)}],
                 ['r', {little:2, balanced:Math.round(n*0.25), focus:Math.round(n*0.45)}]];
  for(const [eq, q] of order){
    const mode = mix[eq]; if(!mode || mode==='off') continue;
    let quota = q[mode];
    const ok = shuffle([...slots.keys()]).filter(i => assign[i]===null &&
      EXERCISES.some(x=>x.e===eq && slots[i].patterns.includes(x.p) && x.r.includes(slots[i].role)));
    for(const i of ok){ if(quota<=0) break; assign[i]=eq; quota--; }
  }
  return assign.map(a=>a||'b');
}

function maxLvlFor(state, eq){
  // "a little": only easy, level-appropriate moves for that equipment
  const mode = state.settings.mix[eq];
  if(mode==='little') return eq==='p' ? 3 : 2;
  return null;
}

// ---------- Blocks ----------
function warmup(ctx){
  const secs = (ctx.state.settings.warmMin||6)*60; const steps=[];
  const care = ctx.state.settings.backCare;
  const okW = x => x.r.includes('w') && !isBlocked(ctx.state, x.k) && ctx.allowedEq.has(x.e) && !(ctx.state.settings.quiet && x.f.includes('J')) && !(care && /[NB]/.test(x.f));
  const fixed = care ? ['cat_cow_gentle','chin_tuck','wall_slide','bird_dog','bridge'].map(k=>BY_KEY[k]).filter(x=>!isBlocked(ctx.state,x.k)) : [];
  const mob = shuffle(EXERCISES.filter(x=>okW(x) && x.p==='mob' && !fixed.includes(x) && x.k!=='cat_cow'));
  const act = shuffle(EXERCISES.filter(x=>okW(x) && x.p!=='mob' && !fixed.includes(x)));
  const list = care ? [...fixed.slice(0,3), ...mob.slice(0,1), ...fixed.slice(3), ...act.slice(0,2)] : [...mob.slice(0,4), ...act.slice(0,4)];
  let t=0;
  for(const ex of list){
    if(t>=secs) break;
    if(ex.f.includes('S')){ steps.push({t:'work',ex:ex.k,dur:25,side:'L'}); steps.push({t:'work',ex:ex.k,dur:25,side:'R',switch:true}); t+=50; }
    else { steps.push({t:'work',ex:ex.k,dur:40}); t+=40; }
    ctx.exs.add(ex.k); ctx.used.add(ex.k);
  }
  return {name:'Warm-up', kind:'warmup', steps};
}

function tabata(ctx, label='Tabata'){
  const seq = [['squat','lunge'],['hpush','vpush'],['cardio'],['coreA','coreF'],ctx.state.settings.backCare?['glute']:['glute','hinge'],['hpull','vpull'],['cardio','squat','lunge'],['coreR','coreL','coreA']];
  const steps=[];
  for(const pats of seq){
    const p0 = pats[0];
    // equipment allowed in tabata when mix-in says balanced/focus for db/band; bar never in tabata
    let eq=null; const r=rnd();
    if(ctx.state.settings.mix.d==='focus' && r<0.4) eq='d'; else if(ctx.state.settings.mix.d==='balanced' && r<0.2) eq='d';
    else if(ctx.state.settings.mix.r==='focus' && r<0.5) eq='r';
    const target = lvlTarget(ctx, p0, ctx.light?-0.3:0);
    let ex = (eq && choose(ctx,{patterns:pats, role:'t', eq, target, noSide:true})) || choose(ctx,{patterns:pats, role:'t', eq:'b', target, noSide:true}) || choose(ctx,{patterns:pats, role:'t', target, noSide:true})
      || choose(ctx,{patterns:['cardio','squat','coreA','glute'], role:'t', target, noSide:true});
    if(!ex){ // pool used up (long Tabata days): allow moves from earlier blocks, never repeat within this block
      const inBlock = new Set(steps.filter(s=>s.ex).map(s=>s.ex));
      const c2 = {...ctx, used:inBlock};
      ex = choose(c2,{patterns:pats, role:'t', target, noSide:true}) || choose(c2,{patterns:['cardio','squat','coreA','glute','lunge','hpush'], role:'t', target, noSide:true});
    }
    if(!ex) continue;
    steps.push(workStep(ctx, ex, 20));
    steps.push({t:'rest', dur:10, tabata:true});
  }
  steps.pop();
  return {name:label, kind:'tabata', steps, info:'20 s on · 10 s off × 8'};
}

// Balanced strength slots. Pull volume >= push volume across the week.
function strengthSlots(ctx){
  const wk = weeklyCounts(ctx.state); const e = ctx.emphasis; const n = ctx.history.length;
  const pushP = n%2 ? ['vpush'] : ['hpush'];
  const pullP = ctx.allowedEq.has('p') && n%2===0 ? ['vpull'] : (n%2 ? ['hpull'] : ['vpull','hpull']);
  const legP  = (n%2) ? ['lunge'] : ['squat'];
  const hipP  = (n%3===0) ? ['glute'] : ['hinge','glute'];
  const coreSubs = [['coreA'],['coreR'],['coreL'],['coreF']]; const coreP = coreSubs[n%4];
  const slots = [{patterns:pushP},{patterns:pullP},{patterns:legP},{patterns:hipP},{patterns:coreP}];
  const pushVol = (wk.hpush||0)+(wk.vpush||0), pullVol=(wk.hpull||0)+(wk.vpull||0);
  let extra;
  if(e==='push') extra = pullVol < pushVol ? (pullP[0]==='vpull'?['hpull']:['vpull']) : ['tri','vpush','hpush'].filter(p=>!pushP.includes(p));
  else if(e==='pull') extra = rnd()<0.35 ? ['bi'] : (pullP.includes('vpull')?['hpull']:['vpull','hpull']);
  else if(e==='legs') extra = legP[0]==='squat' ? ['lunge'] : ['squat'];
  else extra = ['coreA','coreR','coreF','coreL'].filter(c=>!coreP.includes(c));
  if(extra.includes('vpush')||extra.includes('hpush')) { /* keep weekly balance */ if(pushVol>pullVol+2) extra=['hpull']; }
  slots.push({patterns:extra, extra:true});
  // on legs day put lower body first; otherwise interleave upper/lower
  const order = e==='legs' ? [2,0,3,1,5,4] : [0,2,1,3,5,4];
  return order.map(i=>({...slots[i], role:'s'}));
}

function fillSlots(ctx, slots, work, waveOn=true){
  const eqs = equipmentPlan(ctx.state, slots); const out=[];
  slots.forEach((sl,i)=>{
    const wave = waveOn ? (i%2===0? 0.5 : -0.5) : 0; // harder, easier, harder...
    const target = lvlTarget(ctx, sl.patterns[0], wave);
    const eq = eqs[i];
    let ex = choose(ctx,{patterns:sl.patterns, role:sl.role, eq, target, maxLvl:maxLvlFor(ctx.state,eq)})
          || choose(ctx,{patterns:sl.patterns, role:sl.role, eq:'b', target})
          || choose(ctx,{patterns:sl.patterns, role:sl.role, target});
    if(ex) out.push(ex);
  });
  return out;
}

function exSteps(ctx, ex, work, ramp=false){
  const o = ramp ? {ramp:true} : {};
  if(ex.f.includes('S')){
    const side = r5(Math.max(25, work*0.7));
    return [workStep(ctx,ex,side,{side:'L',...o}), workStep(ctx,ex,side,{side:'R',switch:true,...o})];
  }
  return [workStep(ctx, ex, work, o)];
}

function circuit(ctx, budgetSec){
  const work = r5(ctx.phase.work + ctx.inten.work + (ctx.state.effort||0)*3);
  const rest = r5(Math.max(10, ctx.phase.rest + ctx.inten.rest - (ctx.state.effort||0)*2));
  const slots = strengthSlots(ctx);
  const useSlots = ctx.light ? slots.filter(s=>!s.extra) : slots;
  const exs = fillSlots(ctx, useSlots, work);
  const roundSec = list => list.reduce((a,ex)=>a + (ex.f.includes('S')? 2*r5(Math.max(25,work*0.7))+5 : work) + rest, 0);
  while(exs.length>3 && 2*roundSec(exs)+60 > budgetSec*1.15) exs.pop(); // short budgets: fewer moves, still 2 rounds
  const perRound = exs.reduce((a,ex)=>a + (ex.f.includes('S')? 2*r5(Math.max(25,work*0.7))+5 : work) + rest, 0);
  const roundRest = 60;
  let rounds = Math.max(2, Math.min(ctx.light?3:4, Math.floor((budgetSec + roundRest) / (perRound + roundRest))));
  const steps=[];
  for(let r=0;r<rounds;r++){
    exs.forEach((ex,i)=>{ steps.push(...exSteps(ctx, ex, work, r===0)); if(i<exs.length-1) steps.push({t:'rest',dur:rest}); });
    if(r<rounds-1) steps.push({t:'rest', dur:roundRest, label:`Round ${r+2} of ${rounds}`});
  }
  // pattern counts: count once per exercise per session, not per round
  return {name:'Strength circuit', kind:'circuit', steps, info:`${exs.length} moves × ${rounds} rounds · ${work}s on / ${rest}s off`};
}

function finisher(ctx){
  if(ctx.light) return flow(ctx, 5);
  const type = pick(['emom','amrap','emom']);
  const pats = {push:[['hpush','vpush'],['hpull','vpull']], legs:[['squat','lunge'],['glute','cardio']], pull:[['hpull','vpull'],['coreA']], core:[['coreA','coreF'],['coreR','cardio']]}[ctx.emphasis];
  const exs = pats.map(p => choose(ctx,{patterns:p, role:'f', target:lvlTarget(ctx,p[0]), noSide:true})).filter(Boolean);
  if(type==='amrap'){
    const third = choose(ctx,{patterns:['cardio','coreA','squat'], role:'f', target:lvlTarget(ctx,'cardio'), noSide:true});
    if(third) exs.push(third);
    const moves = exs.map(ex => { const s=workStep(ctx,ex,0); return {ex:ex.k, reps:s.reps||10, hold:ex.f.includes('H'), weight:s.weight}; });
    return {name:'Finisher · AMRAP 5', kind:'amrap', steps:[{t:'amrap', dur:300, moves}], info:'As many rounds as possible in 5 min'};
  }
  const steps=[];
  for(let m=0;m<5;m++){ const ex=exs[m%exs.length]; steps.push(workStep(ctx,ex,40)); steps.push({t:'rest',dur:20}); }
  steps.pop();
  return {name:'Finisher · EMOM 5', kind:'emom', steps, info:'Every minute: 40 s work, rest the remainder'};
}

function flow(ctx, minutes){
  const list = shuffle(EXERCISES.filter(x=>(x.p==='mob'||x.p==='str') && !isBlocked(ctx.state,x.k) && ctx.allowedEq.has(x.e) && !ctx.used.has(x.k) && !(ctx.state.settings.backCare && /[NB]/.test(x.f))));
  const steps=[]; let t=0;
  for(const ex of list){ if(t>=minutes*60) break; ctx.used.add(ex.k);
    if(ex.f.includes('S')){ steps.push({t:'work',ex:ex.k,dur:30,side:'L'}); steps.push({t:'work',ex:ex.k,dur:30,side:'R',switch:true}); t+=60; }
    else { steps.push({t:'work',ex:ex.k,dur:45}); t+=45; } ctx.exs.add(ex.k); }
  return {name:'Mobility flow', kind:'flow', steps, info:'Slow, controlled, breathe'};
}

function stretch(ctx){
  const minutes = (ctx.state.settings.stretchMin||9) + (ctx.light?4:0);
  // cover all areas: hips, hamstrings, chest/shoulders, back, quads/calves
  const groups = [['pigeon','figure4','low_lunge','butterfly','frog'],['ham_stretch','fwd_fold','down_dog'],['chest_open','cross_shoulder','tri_stretch','thread_needle'],['cobra','sphinx','spinal_twist','cat_cow','knees_chest','happy_baby'],['quad_stretch','calf_stretch','side_bend','hang_stretch']];
  const chosen=[];
  for(let round=0; round<3; round++) for(const g of groups){ const opts=shuffle(g).filter(k=>!ctx.used.has(k) && !isBlocked(ctx.state,k) && BY_KEY[k] && ctx.allowedEq.has(BY_KEY[k].e) && !(ctx.state.settings.backCare && /[NB]/.test(BY_KEY[k].f))); if(opts[0]){ chosen.push(opts[0]); ctx.used.add(opts[0]); } }
  const steps=[]; let t=0;
  for(const k of chosen){ if(t>=minutes*60-30) break; const ex=BY_KEY[k];
    const sd = ctx.state.settings.backCare ? 30 : 35, nd = ctx.state.settings.backCare ? 40 : 50;
    if(ex.f.includes('S')){ steps.push({t:'work',ex:k,dur:sd,side:'L'}); steps.push({t:'work',ex:k,dur:sd,side:'R',switch:true}); t+=sd*2; }
    else { steps.push({t:'work',ex:k,dur:nd}); t+=nd; } ctx.exs.add(k); }
  steps.push({t:'work', ex:'child', dur:45, final:true}); ctx.exs.add('child');
  return {name:'Stretch & yoga', kind:'stretch', steps};
}

// ---------- single formats ----------
function balancedPatterns(ctx, n){
  const base = [['hpush'],['hpull','vpull'],['squat'],['hinge','glute'],['coreA'],['vpush'],['lunge'],['hpull','vpull'],['coreR','coreF','coreL'],['glute'],['cardio'],['tri','bi']];
  return Array.from({length:n},(_,i)=>({patterns:base[i%base.length], role:'s'}));
}
function emomFormat(ctx, mins){
  const work = r5(40 + ctx.inten.work + (ctx.state.effort||0)*3);
  const steps=[]; let exs=[]; let total=0;
  for(let m=0;m<mins;m++){ if(m%10===0){ const pats=balancedPatterns(ctx,10).slice((m/10%2)*5,(m/10%2)*5+5); exs=fillSlots(ctx, pats, 40); total+=exs.length; }
    const ex = exs[m%exs.length]; steps.push(workStep(ctx,ex,Math.min(50,work))); steps.push({t:'rest',dur:60-Math.min(50,work)}); }
  steps.pop();
  return [{name:`EMOM ${mins}`, kind:'emom', steps, info:`${total} moves, fresh set every 10 min`}];
}
function amrapFormat(ctx, mins){
  const per = Math.max(5, Math.floor((mins-2)/3));
  return [0,1,2].map(i=>amrapBlock(ctx, per, i, `AMRAP ${i+1} · ${per} min`));
}
const AMRAP_GROUPS = [[['hpush','vpush'],['squat','lunge'],['coreA'],['cardio']],[['hpull','vpull'],['hinge','glute'],['coreR','coreF'],['cardio']],[['vpush','tri'],['lunge','squat'],['hpull','bi'],['coreL','coreA']]];
function amrapBlock(ctx, mins, gi, label){
  const g = AMRAP_GROUPS[gi % AMRAP_GROUPS.length];
  const moves = g.map(p=>choose(ctx,{patterns:p, role:'s', target:lvlTarget(ctx,p[0]), noSide:true}) || choose(ctx,{patterns:p, role:'t', target:lvlTarget(ctx,p[0]), noSide:true})).filter(Boolean)
    .map(ex=>{ const s=workStep(ctx,ex,0); return {ex:ex.k, reps:s.reps||10, hold:ex.f.includes('H'), weight:s.weight}; });
  return {name: label || `AMRAP · ${mins} min`, kind:'amrap', steps:[{t:'amrap',dur:mins*60,moves}], info:'As many rounds as possible'};
}
function classicFormat(ctx, mins){
  const n = Math.max(2, Math.min(9, Math.round(mins/4.2)));
  const exs = fillSlots(ctx, balancedPatterns(ctx,n), 45, false);
  const work = r5(ctx.phase.work + ctx.inten.work + 5);
  const steps=[];
  exs.forEach((ex,i)=>{ for(let s=0;s<3;s++){ steps.push(...exSteps(ctx,ex,work,s===0).map(st=>({...st,set:`Set ${s+1} of 3`}))); if(s<2) steps.push({t:'rest',dur:30}); } if(i<exs.length-1) steps.push({t:'rest',dur:45}); });
  return [{name:'Classic sets', kind:'classic', steps, info:`${exs.length} exercises × 3 sets`}];
}

// ---------- main ----------
export function generate(state, opts={}){
  const s = state.settings; const format = opts.format || s.format || 'mixed';
  const mainMin = opts.minutes || s.mainMin || 35;
  const count = state.history.length; const did = state.history.some(h=>h.date===today());
  let intensity = INT_CYCLE[count%3], emphasis = EMPH_CYCLE[count%4];
  if(did){ intensity='light'; }
  const ease = (state.ease||0) > 0;
  if(ease || format==='recovery' || format==='mobility') intensity='light';
  const phase = phaseFor(state);
  if(phase.week===4 && intensity==='hard') intensity='medium';
  const gym = (opts.location || s.location) === 'gym';
  const st = {...state, settings:{...s, mix: {...(gym ? s.gymMix : s.mix)}, dbWeights: gym ? s.gymWeights : s.dbWeights}};
  if(ease || format==='recovery'){ st.settings.backCare = true; for(const k of ['d','p','g']) if(st.settings.mix[k] && st.settings.mix[k]!=='off') st.settings.mix[k] = format==='recovery' ? 'off' : 'little'; if(format==='recovery') st.settings.quiet = true; }
  const allowedEq = new Set(['b', ...['d','p','r','g'].filter(e=>st.settings.mix[e] && st.settings.mix[e]!=='off')]);
  const ctx = {state:st, gym, history:state.history, phase, intensity, inten:INTENSITY[intensity], light:intensity==='light', emphasis, used:new Set(), recent:recentSet(state), allowedEq, pat:{}, exs:new Set()};
  const blocks = (opts.warmup ?? s.warmup ?? true) ? [warmup(ctx)] : [];
  if(format==='mixed'){
    blocks.push(tabata(ctx));
    const fin = finisher(ctx);
    const finSec = fin.steps.reduce((a,x)=>a+x.dur,0);
    const budget = mainMin*60 - 240 - finSec - 60;
    blocks.push(circuit(ctx, budget));
    blocks.push(fin);
  } else if(format==='tabata'){
    const n = Math.max(2, Math.floor((mainMin+1)/5));
    for(let i=0;i<n;i++) blocks.push(tabata(ctx, `Tabata ${i+1} of ${n}`));
  } else if(format==='emom') blocks.push(...emomFormat(ctx, mainMin));
  else if(format==='amrap') blocks.push(...amrapFormat(ctx, mainMin));
  else if(format==='classic') blocks.push(...classicFormat(ctx, mainMin));
  else if(format==='mobility') blocks.push(flow(ctx, mainMin));
  else if(format==='custom'){
    const order = ['tabata','circuit','classic','emom','amrap'];
    const chosen = order.filter(b => (opts.blocks || s.customBlocks || []).includes(b));
    if(!chosen.length) chosen.push('circuit');
    const tabSec = chosen.includes('tabata') ? 300 : 0;
    const others = chosen.filter(b=>b!=='tabata');
    const per = others.length ? Math.max(240, (mainMin*60 - tabSec) / others.length) : 0;
    if(chosen.includes('tabata')){ const n = others.length ? 1 : Math.min(7, Math.max(2, Math.floor((mainMin+1)/5))); for(let i=0;i<n;i++) blocks.push(tabata(ctx, n>1?`Tabata ${i+1} of ${n}`:'Tabata')); }
    for(const b of others){
      const m = Math.max(4, Math.round(per/60));
      if(b==='circuit') blocks.push(circuit(ctx, per));
      else if(b==='classic') blocks.push(...classicFormat(ctx, m));
      else if(b==='emom') blocks.push(...emomFormat(ctx, m));
      else if(b==='amrap'){ const k = Math.max(1, Math.round(m/10)); const each = Math.max(4, Math.round(m/k)); for(let i=0;i<k;i++) blocks.push(amrapBlock(ctx, each, ctx.history.length+i, k>1?`AMRAP ${i+1} of ${k} · ${each} min`:undefined)); }
    }
  }
  else if(format==='recovery'){ blocks.push(flow(ctx, Math.min(mainMin, 20))); }
  if(format!=='mobility' && format!=='recovery' && (opts.stretch ?? s.stretch ?? true)) blocks.push(stretch(ctx));
  for(const k of ctx.exs){ const x=BY_KEY[k]; if(x && x.p!=='mob' && x.p!=='str') ctx.pat[x.p]=(ctx.pat[x.p]||0)+1; }
  const est = blocks.reduce((a,b)=>a+b.steps.reduce((x,st)=>x+st.dur,0),0) + blocks.length*15;
  const fmtName = {custom:'My mix',recovery:'Recovery',mixed:'Mixed',tabata:'Tabata',emom:'EMOM',amrap:'AMRAP',classic:'Classic sets',mobility:'Mobility'}[format];
  return { id: Date.now().toString(36), date: today(), format, fmtName, intensity, emphasis: ['mobility','recovery'].includes(format)?'mobility':emphasis,
    week: phase.week, phaseName: phase.name, block: state.block.n, title: format==='recovery' ? 'Gentle recovery · spine-safe' : `${gym?'Gym · ':''}Full body · ${EMPH_LABEL[format==='mobility'?'mobility':emphasis]}`,
    blocks, est, exs:[...ctx.exs], pat:ctx.pat, second: did, gym };
}

// Feedback adjusts future sessions
export function applyFeedback(state, plan, fb){
  if(fb==='hurt'){ state.ease = 3; state.effort = Math.max(-2,(state.effort||0)-1.5);
    for(const p of Object.keys(plan.pat||{})) if(state.levels[p]!=null) state.levels[p]=Math.max(1,+(state.levels[p]-0.3).toFixed(2));
    return; }
  if(state.ease>0) state.ease--;
  const d = fb==='easy'? 1 : fb==='hard'? -1 : 0;
  state.effort = Math.max(-2, Math.min(2, (state.effort||0) + d*0.75));
  const step = fb==='easy'? 0.2 : fb==='hard'? -0.2 : 0.05;
  for(const p of Object.keys(plan.pat||{})) if(state.levels[p]!=null) state.levels[p] = Math.max(1, Math.min(5, +(state.levels[p]+step).toFixed(2)));
}

// Month check-in recalibrates levels
export function applyCheckin(state, c){
  const L = state.levels; const fp=+c.pushups||0, kp=+c.kneePushups||0, pu=+c.pullups||0, pl=+c.plank||0, hg=+c.hang||0;
  L.hpush = fp>=20?4: fp>=10?3.5: fp>=5?3: fp>=1?2.5: kp>=20?2.2: 1.5;
  L.vpush = Math.max(1.5, L.hpush-0.2); L.tri = Math.max(1.5, L.hpush-0.5);
  L.vpull = pu>=8?4.2: pu>=5?3.8: pu>=3?3.3: pu>=1?2.6: hg>=45?2: 1.5;
  L.hpull = Math.max(L.hpull, Math.min(4, L.vpull)); L.bi = Math.max(1.5, L.vpull-0.5);
  L.coreA = pl>=150?4: pl>=90?3.3: pl>=60?2.7: pl>=30?2: 1.5;
  state.checkins.push({date:today(), ...c});
}

export function nextTargets(state){
  const c = state.checkins[state.checkins.length-1]; if(!c) return null;
  const fp=+c.pushups||0, pu=+c.pullups||0, pl=+c.plank||0, hg=+c.hang||0;
  return [
    fp ? `${fp+3} full push-ups` : `3 full push-ups`,
    pu ? `${pu+1} strict pull-up${pu+1>1?'s':''}` : `first strict pull-up`,
    `${Math.round((pl+20)/5)*5} s plank`,
    `${Math.round((hg+15)/5)*5} s dead hang`,
  ];
}

// ---------- review & swap ----------
function planSettings(state, plan){
  const s = state.settings; const gym = !!plan.gym;
  const st = {...state, settings:{...s, mix:{...(gym ? s.gymMix : s.mix)}, dbWeights: gym ? s.gymWeights : s.dbWeights}};
  if((state.ease||0)>0 || plan.format==='recovery') st.settings.backCare = true;
  return st;
}
const NEAR = {hpush:['vpush'],vpush:['hpush'],hpull:['vpull'],vpull:['hpull'],squat:['lunge'],lunge:['squat'],hinge:['glute'],glute:['hinge'],coreA:['coreF','coreL','coreR'],coreR:['coreL','coreA'],coreL:['coreR','coreA'],coreF:['coreA'],cardio:['squat','coreA'],bi:['hpull'],tri:['hpush'],mob:['str'],str:['mob']};

// Where an exercise is used in the plan (block kinds) — tabata/amrap need two-sided moves
function usage(plan, key){
  const kinds=new Set();
  for(const b of plan.blocks) for(const s of b.steps){ if(s.ex===key || (s.moves||[]).some(m=>m.ex===key)) kinds.add(b.kind); }
  return kinds;
}

export function alternatives(state, plan, key, n=6){
  const orig = BY_KEY[key]; if(!orig) return [];
  const st = planSettings(state, plan); const s = st.settings;
  const allowed = new Set(['b', ...['d','p','r','g'].filter(e=>s.mix[e] && s.mix[e]!=='off')]);
  const kinds = usage(plan, key); const noSide = kinds.has('tabata') || kinds.has('amrap') || kinds.has('emom');
  const inPlan = new Set(plan.exs||[]);
  const ok = x => x.k!==key && !inPlan.has(x.k) && allowed.has(x.e) && (plan.gym || !x.k.startsWith('g_'))
    && !isBlocked(st, x.k) && !(s.backCare && /[NB]/.test(x.f)) && !(s.quiet && x.f.includes('J')) && !(noSide && x.f.includes('S')) && !(kinds.has('tabata') && x.f.includes('H'));
  const role = kinds.has('tabata') ? 't' : (kinds.has('warmup') ? 'w' : (kinds.has('stretch')||kinds.has('flow')) ? 'y' : 's');
  const roleOk = x => x.r.includes(role) || (role==='s' && x.r.includes('f')) || (role==='y' && x.p==='mob');
  const score = x => Math.abs(x.l-orig.l) + (x.p===orig.p?0:1.5) + (roleOk(x)?0:2.5) + Math.random()*0.4;
  let c = EXERCISES.filter(x=>x.p===orig.p && ok(x));
  if(c.length < n) c = c.concat(EXERCISES.filter(x=>(NEAR[orig.p]||[]).includes(x.p) && ok(x)));
  return c.sort((a,b)=>score(a)-score(b)).slice(0,n);
}

export function swapInPlan(state, plan, oldKey, newKey){
  const nx = BY_KEY[newKey]; const st = planSettings(state, plan);
  const ctx = {state:st, phase:phaseFor(state), intensity:plan.intensity, exs:new Set()};
  for(const b of plan.blocks){
    const out=[];
    for(let i=0;i<b.steps.length;i++){
      const s=b.steps[i];
      if(s.t==='amrap'){ s.moves = s.moves.map(m=>{ if(m.ex!==oldKey) return m; const w=workStep(ctx,nx,0); return {ex:newKey, reps:w.reps||10, hold:nx.f.includes('H'), weight:w.weight}; }); out.push(s); continue; }
      if(s.ex!==oldKey || s.t!=='work'){ out.push(s); continue; }
      const extra = {ramp:s.ramp, set:s.set, final:s.final};
      if(s.side==='L' && b.steps[i+1] && b.steps[i+1].ex===oldKey && b.steps[i+1].side==='R'){
        const total = s.dur + b.steps[i+1].dur; i++;
        if(nx.f.includes('S')) { out.push(workStep(ctx,nx,s.dur,{...extra,side:'L'})); out.push(workStep(ctx,nx,s.dur,{...extra,side:'R',switch:true})); }
        else out.push(workStep(ctx,nx,Math.min(total, Math.max(s.dur, 45)),extra));
      } else if(nx.f.includes('S') && !s.side && s.dur>=30){
        const half = Math.max(20, Math.round(s.dur*0.7/5)*5);
        out.push(workStep(ctx,nx,half,{...extra,side:'L'})); out.push(workStep(ctx,nx,half,{...extra,side:'R',switch:true}));
      } else out.push(workStep(ctx,nx,s.dur,{...extra, side:s.side, switch:s.switch}));
    }
    b.steps = out.map(x=>{ for(const k of Object.keys(x)) if(x[k]===undefined) delete x[k]; return x; });
  }
  plan.exs = (plan.exs||[]).filter(k=>k!==oldKey); if(!plan.exs.includes(newKey)) plan.exs.push(newKey);
  plan.pat = {}; for(const k of plan.exs){ const x=BY_KEY[k]; if(x && x.p!=='mob' && x.p!=='str') plan.pat[x.p]=(plan.pat[x.p]||0)+1; }
  plan.est = plan.blocks.reduce((a,b)=>a+b.steps.reduce((x,st)=>x+st.dur,0),0) + plan.blocks.length*15;
  return plan;
}

// Re-dose a single step for a new exercise (used mid-workout)
export function restep(state, plan, step, newKey){
  const st = planSettings(state, plan); const ctx = {state:st, phase:phaseFor(state), intensity:plan.intensity, exs:new Set()};
  const w = workStep(ctx, BY_KEY[newKey], step.dur, {});
  return {...step, ex:newKey, reps:w.reps, weight:w.weight, dur: step.dur};
}
