// Voice coach: browser speech + Web Audio beeps.
const PREFERRED = ['Samantha','Karen','Moira','Serena','Tessa','Ava','Allison','Susan','Google UK English Female','Google US English','Microsoft Aria','Microsoft Jenny'];

export class Coach{
  constructor(getSettings){ this.get = getSettings; this.ctx = null; this.voice = null;
    if('speechSynthesis' in window){ speechSynthesis.onvoiceschanged = ()=>{ this.voice=null; }; }
  }
  static voices(){
    if(!('speechSynthesis' in window)) return [];
    return speechSynthesis.getVoices().filter(v=>/^en/i.test(v.lang));
  }
  pickVoice(){
    const s=this.get(); const vs=Coach.voices(); if(!vs.length) return null;
    if(s.voiceName){ const v=vs.find(v=>v.name===s.voiceName); if(v) return v; }
    for(const n of PREFERRED){ const v=vs.find(v=>v.name.startsWith(n)); if(v) return v; }
    return vs.find(v=>v.lang==='en-US') || vs[0];
  }
  setSession(){
    // Safari 17+: control how our sound mixes with Spotify
    try{ if(navigator.audioSession) navigator.audioSession.type = this.get().audioMode || 'ambient'; }catch(e){}
  }
  unlock(){
    this.setSession();
    try{
      if(!this.ctx){ const AC = window.AudioContext||window.webkitAudioContext; if(AC) this.ctx = new AC(); }
      if(this.ctx && this.ctx.state==='suspended') this.ctx.resume();
      if(this.ctx){ const b=this.ctx.createBuffer(1,1,22050); const src=this.ctx.createBufferSource(); src.buffer=b; src.connect(this.ctx.destination); src.start(0); }
    }catch(e){}
    try{ if('speechSynthesis' in window){ const u=new SpeechSynthesisUtterance(' '); u.volume=0; speechSynthesis.speak(u); } }catch(e){}
  }
  say(text, interrupt=false){
    const s=this.get(); if(!s.voice || !text || !('speechSynthesis' in window)) return;
    try{
      if(interrupt) speechSynthesis.cancel();
      const u=new SpeechSynthesisUtterance(text);
      if(!this.voice) this.voice=this.pickVoice();
      if(this.voice){ u.voice=this.voice; u.lang=this.voice.lang; } else u.lang='en-US';
      u.rate=1.02; u.pitch=1; u.volume=1;
      speechSynthesis.speak(u);
    }catch(e){}
  }
  stop(){ try{ speechSynthesis.cancel(); }catch(e){} }
  beep(freq=880, dur=0.12, vol=0.35, when=0){
    const s=this.get(); if(!s.beeps || !this.ctx) return;
    try{
      if(this.ctx.state==='suspended') this.ctx.resume();
      const t=this.ctx.currentTime+when; const o=this.ctx.createOscillator(); const g=this.ctx.createGain();
      o.type='sine'; o.frequency.value=freq; g.gain.setValueAtTime(0.0001,t); g.gain.exponentialRampToValueAtTime(vol,t+0.01); g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
      o.connect(g).connect(this.ctx.destination); o.start(t); o.stop(t+dur+0.02);
    }catch(e){}
  }
  tick(){ this.beep(880,0.1,0.3); }
  count(n){ this.tick(); this.say(String(n), true); }
  go(){ this.beep(1320,0.28,0.4); this.say('Go!', true); }
  endBeep(){ this.beep(1046,0.12,0.35); this.beep(1318,0.2,0.35,0.15); }
  restBeep(){ this.beep(660,0.14,0.25); }
  test(){
    this.say('Sound test. Get ready.', true);
    setTimeout(()=>this.count(3),1800); setTimeout(()=>this.count(2),2800); setTimeout(()=>this.count(1),3800);
    setTimeout(()=>this.go(),4800); setTimeout(()=>this.say('Switch sides'),6300); setTimeout(()=>this.say('Rest 15 seconds. Next up: goblet squat'),7800);
  }
}
