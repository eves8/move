import { EXERCISES, BY_KEY } from './exercises.js';
import { generate, applyFeedback, applyCheckin, nextTargets, phaseFor, alternatives, swapInPlan, restep, DEFAULT_LEVELS, PATTERN_LABEL, EMPH_LABEL } from './engine.js';
import { Coach } from './coach.js';

const VERSION = '1.3.0';
const KEY = 'move.v1';
const $ = (s, el=document) => el.querySelector(s);
const esc = s => String(s??'').replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const todayStr = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const mins = s => Math.round(s/60);

// ---------------- state ----------------
const DEFAULT = {
  settings:{ location:'home', format:'mixed', mainMin:35, warmMin:6, stretchMin:9,
    mix:{ d:'balanced', p:'little', r:'little', g:'off' }, dbWeights:[2,3,4,5],
    gymMix:{ g:'focus', d:'balanced', p:'little', r:'off' }, gymWeights:[4,6,8,10,12],
    quiet:false, warmup:true, stretch:true, backCare:true, blocked:[], customBlocks:['tabata','emom','amrap'], voice:true, beeps:true, voiceName:'', audioMode:'ambient', theme:'auto' },
  levels:{...DEFAULT_LEVELS}, effort:0,
  block:{ n:1, start:null, done:0, goal:24 },
  history:[], checkins:[{date:null, pushups:'', kneePushups:25, pullups:1, plank:60, hang:60, seed:true}],
  current:null,
};
function load(){
  try{ const s = JSON.parse(localStorage.getItem(KEY)); if(s) return deepMerge(structuredClone(DEFAULT), s); }catch(e){}
  return structuredClone(DEFAULT);
}
function deepMerge(a,b){ for(const k in b){ if(b[k] && typeof b[k]==='object' && !Array.isArray(b[k]) && a[k] && typeof a[k]==='object') deepMerge(a[k],b[k]); else a[k]=b[k]; } return a; }
let S = load();
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(S)); }catch(e){ console.warn('save failed', e); } }
if(navigator.storage?.persist) navigator.storage.persist().catch(()=>{});
if(!S.block.start){ S.block.start = todayStr(); save(); }

function applyTheme(){ const t=S.settings.theme; if(t==='auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.dataset.theme=t; }
applyTheme();

function plan(force=false){
  const loc = S.settings.location, fmt = S.settings.format, m = S.settings.mainMin;
  const c = S.current;
  const cbk = (fmt==='custom' ? (S.settings.customBlocks||[]).join(',') : '') + '|w' + (S.settings.warmup!==false) + '|s' + (S.settings.stretch!==false);
  const stale = !c || c.cbk!==cbk || c.date!==todayStr() || c.format!==fmt || c.mainMin!==m || c.location!==loc || c.histLen!==S.history.length || c.ease!==(S.ease||0);
  if(force || stale){
    S.current = generate(S, {format:fmt, minutes:m, location:loc});
    Object.assign(S.current, {cbk, mainMin:m, location:loc, histLen:S.history.length, ease:S.ease||0});
    save();
  }
  return S.current;
}

// ---------------- media ----------------
const P_ = (id,n) => (window.IMGDATA && window.IMGDATA[id+'/'+n]) || `img/${id}/${n}.jpg`;
function imgSrc(ex, frame=0){
  if(!ex.i) return null; const [id, fixed] = ex.i.split('#');
  return P_(id, fixed!=null?fixed:frame);
}
function thumb(ex){ const s=imgSrc(ex,0); return s ? `style="background-image:url('${s}')"` : ''; }
let loopTimer=null;
function mountMedia(el, ex, side){
  clearInterval(loopTimer); el.innerHTML='';
  if(!ex){ return; }
  const sideTag = side ? `<span class="side">${side==='L'?'Left side':'Right side'}</span>` : '';
  // later upgrade: own clips -> customClipFor(ex.k) returns a blob URL, played muted + looping
  if(!ex.i){ el.innerHTML = `<div class="ph"><div><b>${esc(ex.n)}</b><span>${esc(ex.c)}</span></div></div>${sideTag}`; return; }
  const [id, fixed] = ex.i.split('#');
  if(fixed!=null){ el.innerHTML = `<img src="${P_(id,fixed)}" alt="">${sideTag}`; return; }
  el.innerHTML = `<img src="${P_(id,0)}" alt=""><img src="${P_(id,1)}" alt="" style="opacity:0">${sideTag}`;
  const [a,b] = el.querySelectorAll('img'); let on=false;
  loopTimer = setInterval(()=>{ on=!on; b.style.opacity = on?1:0; }, 1100);
}

// ---------------- views ----------------
const tabs = document.querySelectorAll('#tabs button');
tabs.forEach(b=>b.onclick=()=>show(b.dataset.tab));
function show(tab){
  tabs.forEach(b=>b.classList.toggle('on', b.dataset.tab===tab));
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active', v.id==='view-'+tab));
  ({today:renderToday, progress:renderProgress, settings:renderSettings})[tab]();
  window.scrollTo(0,0);
}

function ring(done, goal, size=58){
  const r=(size-8)/2, c=2*Math.PI*r, p=Math.min(1, done/goal);
  return `<div class="ring" style="width:${size}px;height:${size}px"><svg width="${size}" height="${size}"><circle cx="${size/2}" cy="${size/2}" r="${r}" stroke="var(--surface2)" stroke-width="7" fill="none"/><circle cx="${size/2}" cy="${size/2}" r="${r}" stroke="var(--accent)" stroke-width="7" fill="none" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c*(1-p)}"/></svg><b>${done}/${goal}</b></div>`;
}
const blockSecs = b => b.steps.reduce((a,s)=>a+s.dur,0);
const intensityPill = p => `<span class="pill ${p.intensity==='hard'?'hard':p.intensity==='light'?'light':''}">${p.intensity[0].toUpperCase()+p.intensity.slice(1)} day</span>`;

const FORMATS = [['mixed','Mixed'],['custom','Build my own'],['tabata','Tabata'],['emom','EMOM'],['amrap','AMRAP'],['classic','Classic sets'],['mobility','Mobility / yoga'],['recovery','Recovery']];
const FORMAT_INFO = {
  mixed:'Warm-up → Tabata → strength circuit → short finisher → stretch. A bit of everything.',
  custom:'You pick the blocks for today. The app fills them with balanced, full-body moves.',
  tabata:'20 s all-out, 10 s rest, 8 different moves = 4 min per round. Short and intense.',
  emom:'Every Minute On the Minute: do the move at the start of each minute (~40 s), rest for the rest of that minute, then the next move.',
  amrap:'As Many Rounds As Possible: a short list of moves with set reps. Repeat the list until the clock runs out and tap +1 after each round.',
  classic:'Traditional strength: each exercise for 3 sets with rest between. Calmer pace.',
  mobility:'Slow mobility and yoga flow. No weights.',
  recovery:'Gentle, spine-safe movement for sore or tired days. Counts toward your goal.',
};
const BLOCK_CHOICES = [['tabata','Tabata'],['circuit','Strength circuit'],['classic','Classic sets'],['emom','EMOM'],['amrap','AMRAP']];
const EQ_NAME = {b:'Bodyweight', d:'Dumbbells', p:'Pull-up bar', r:'Resistance band', g:'Gym machine'};

function stepMeta(b, st){
  if(st.t==='amrap') return '';
  const bits=[];
  if(b.kind==='tabata') bits.push('20 s, as many as you can');
  else bits.push(`${st.dur} s${st.side?' each side':''}`);
  if(st.reps && b.kind!=='tabata') bits.push(`~${st.reps} reps`);
  if(st.weight) bits.push(`${st.weight} kg`);
  return bits.join(' · ');
}
function exRows(b){
  const seen=new Map();
  for(const st of b.steps){
    if(st.t==='amrap'){ for(const m of st.moves) if(!seen.has(m.ex)) seen.set(m.ex, `${m.hold?'20 s hold':m.reps+' reps'}${m.weight?` · ${m.weight} kg`:''} per round`); }
    else if(st.t==='work' && !seen.has(st.ex)) seen.set(st.ex, stepMeta(b, st));
  }
  return [...seen].map(([k,meta])=>{ const x=BY_KEY[k]; return `<button class="exrow" data-ex="${k}"><span class="th" ${thumb(x)}>${x.i?'':'<i>'+esc(x.n[0])+'</i>'}</span><span class="exr-t"><b>${esc(x.n)}</b><span class="muted small">${esc(meta)}</span></span><span class="chev">›</span></button>`; }).join('');
}

function renderToday(){
  const el = $('#view-today'); const ph = phaseFor(S); const s=S.settings;
  const goalDone = S.block.done >= S.block.goal;
  const p = plan();
  const hour = new Date().getHours(); const greet = hour<11?'Good morning':hour<17?'Good afternoon':'Good evening';
  const cb = s.customBlocks || [];
  el.innerHTML = `
    <div class="hello"><div><div class="eyebrow">Month ${S.block.n} · Week ${ph.week} of 4 · ${ph.name}</div><h1>${greet}, Eve</h1></div>${ring(S.block.done, S.block.goal)}</div>
    ${goalDone ? `<div class="banner"><b>Month ${S.block.n} complete.</b> Do a quick check-in to set up next month's plan.<div style="margin-top:10px"><button class="btn primary" id="go-checkin">Month check-in</button></div></div>`:''}
    ${(S.ease||0)>0 ? `<div class="banner small">Easing off after something hurt: ${S.ease} lighter session${S.ease>1?'s':''} left, back moves without heavy weights. If you have numbness, tingling or pain going down your arm, check with your doctor.</div>`:''}
    ${p.second ? `<div class="banner small">Second workout today — this one is automatically lighter. It still counts toward your goal.</div>`:''}
    <div class="label">Where</div>
    <div class="seg" id="loc"><button data-v="home" class="${s.location==='home'?'on':''}">Home</button><button data-v="gym" class="${s.location==='gym'?'on':''}">Extreme Gym</button></div>
    <div class="label">Format</div>
    <div class="chips" id="fmt">${FORMATS.map(([v,l])=>`<button class="chip ${s.format===v?'on':''}" data-v="${v}">${l}</button>`).join('')}</div>
    <div class="fmt-info">${esc(FORMAT_INFO[s.format]||'')}</div>
    ${s.format==='custom' ? `<div class="label">Today's blocks (tap to add or remove)</div><div class="chips wrap" id="cblocks">${BLOCK_CHOICES.map(([v,l])=>`<button class="chip ${cb.includes(v)?'on':''}" data-v="${v}">${cb.includes(v)?'✓ ':''}${l}</button>`).join('')}</div>`:''}
    <div class="label">Main workout length</div>
    <div class="chips" id="len">${[15,25,35,45].map(v=>`<button class="chip ${s.mainMin===v?'on':''}" data-v="${v}">${v} min</button>`).join('')}</div>
    <div class="label">Include</div>
    <div class="chips" id="incl"><button class="chip ${s.warmup!==false?'on':''}" data-v="warmup">${s.warmup!==false?'✓ ':''}Warm-up</button><button class="chip ${s.stretch!==false?'on':''}" data-v="stretch">${s.stretch!==false?'✓ ':''}Stretch at the end</button></div>
    ${s.warmup===false && s.backCare ? `<div class="fmt-info">No warm-up today: the first round still starts lighter (ramp-up). Ease in gently, your neck and back like a warm start.</div>`:''}
    <div class="card session">
      <div class="spread"><span class="eyebrow">${esc(p.fmtName)} · ~${mins(p.est)} min total</span>${intensityPill(p)}</div>
      <h2>${esc(p.title)}</h2>
      <ul class="blocks">${p.blocks.map(b=>`<li><span class="dot ${b.kind}"></span><div><div class="t">${esc(b.name)}</div>${b.info?`<div class="muted small">${esc(b.info)}</div>`:''}</div><span class="min">${Math.max(1,mins(blockSecs(b)))} min</span></li>`).join('')}</ul>
      <button class="start" id="start">Start</button>
      <div class="spread"><button class="linkbtn" id="shuffle">↻ New mix</button>${p.gym?'<span class="muted small">Sauna after? Hydrate well.</span>':''}</div>
    </div>
    <div class="label" style="margin-top:22px">Today's exercises · tap one to see it or swap it</div>
    ${p.blocks.map((b,bi)=>{ const calm=['warmup','stretch'].includes(b.kind); const rows=exRows(b);
      return calm ? `<details class="card exsec"><summary><span class="dot ${b.kind}"></span><b>${esc(b.name)}</b><span class="muted small" style="margin-left:auto">show</span></summary>${rows}</details>`
                  : `<div class="card exsec"><div class="exsec-h"><span class="dot ${b.kind}"></span><b>${esc(b.name)}</b></div>${rows}</div>`; }).join('')}`;
  $('#loc').onclick = e=>{ const v=e.target.dataset.v; if(v){ s.location=v; save(); renderToday(); } };
  $('#fmt').onclick = e=>{ const v=e.target.dataset.v; if(v){ s.format=v; if(v==='custom' && !(s.customBlocks||[]).length) s.customBlocks=['tabata','emom','amrap']; save(); renderToday(); } };
  const cbe=$('#cblocks'); if(cbe) cbe.onclick = e=>{ const v=e.target.closest('[data-v]')?.dataset.v; if(!v) return; const a=s.customBlocks||[]; const i=a.indexOf(v); if(i>=0){ if(a.length>1) a.splice(i,1); } else a.push(v); s.customBlocks=a; save(); renderToday(); };
  $('#incl').onclick = e=>{ const v=e.target.closest('[data-v]')?.dataset.v; if(!v) return; s[v] = (s[v]===false); save(); renderToday(); };
  $('#len').onclick = e=>{ const v=+e.target.dataset.v; if(v){ s.mainMin=v; save(); renderToday(); } };
  $('#shuffle').onclick = ()=>{ plan(true); renderToday(); };
  $('#start').onclick = ()=> startWorkout(p);
  el.querySelectorAll('.exrow').forEach(r=>r.onclick=()=>openExercise(r.dataset.ex, {plan:p}));
  const ci=$('#go-checkin'); if(ci) ci.onclick=openCheckin;
}

// ---------------- exercise detail / swap ----------------
function openExercise(key, {plan:pl, player=false}={}){
  const x = BY_KEY[key]; if(!x) return;
  const lvl = Math.round(x.l);
  openSheet(`<div class="media big" id="ex-media"></div>
    <h2 style="margin-top:12px">${esc(x.n)}</h2>
    <div class="p-meta"><span class="pill">${esc(PATTERN_LABEL[x.p]||'Mobility')}</span><span class="pill rest">${EQ_NAME[x.e]}</span><span class="pill light">Level ${lvl} of 5</span>${x.f.includes('S')?'<span class="pill">One side at a time</span>':''}${x.f.includes('H')?'<span class="pill">Hold</span>':''}</div>
    <p style="font-size:17px;margin:12px 0 0">${esc(x.c)}</p>
    <div class="fb">
      ${pl ? `<button id="ex-swap" style="background:var(--accent);color:var(--on-accent)">Swap for something else<small style="color:inherit;opacity:.85">Pick a similar move that works the same muscles</small></button>`:''}
      ${pl ? `<button id="ex-never">Don't show me this again<small>Swapped now and never picked again (undo in Settings)</small></button>`:''}
      <button id="ex-close">Close</button>
    </div>`);
  mountMedia($('#ex-media'), x);
  $('#ex-close').onclick = closeSheet;
  if(!pl) return;
  $('#ex-swap').onclick = ()=> showAlternatives(key, pl, player);
  $('#ex-never').onclick = ()=>{
    S.settings.blocked = [...new Set([...(S.settings.blocked||[]), key])];
    const alt = alternatives(S, pl, key, 1)[0];
    if(alt) doSwap(key, alt.k, pl, player); else { save(); closeSheet(); }
  };
}
function showAlternatives(key, pl, player){
  const alts = alternatives(S, pl, key, 6);
  const panel = $('#sheet .panel'); clearInterval(loopTimer);
  panel.innerHTML = `<h2>Swap ${esc(BY_KEY[key].n)}</h2><div class="muted">Similar moves for the same muscles, at your level:</div>
    <div style="margin-top:10px">${alts.length ? alts.map(a=>`<button class="exrow" data-ex="${a.k}"><span class="th" ${thumb(a)}>${a.i?'':'<i>'+esc(a.n[0])+'</i>'}</span><span class="exr-t"><b>${esc(a.n)}</b><span class="muted small">${esc(PATTERN_LABEL[a.p]||'Mobility')} · ${EQ_NAME[a.e]} · level ${Math.round(a.l)}</span></span><span class="chev">›</span></button>`).join('') : '<div class="muted">No other options with your current equipment settings.</div>'}</div>
    <div class="fb"><button id="alt-back">Back</button></div>`;
  panel.querySelectorAll('.exrow').forEach(r=>r.onclick=()=>doSwap(key, r.dataset.ex, pl, player));
  $('#alt-back').onclick = ()=>openExercise(key, {plan:pl, player});
}
function doSwap(oldKey, newKey, pl, player){
  swapInPlan(S, pl, oldKey, newKey);
  if(player && P){
    P.tl = P.tl.map((st,i)=>{
      if(i<P.i) return st;
      if(st.t==='work' && st.ex===oldKey) return restep(S, pl, st, newKey);
      if(st.next && st.next.ex===oldKey) return {...st, next:{...st.next, ex:newKey}};
      if(st.t==='amrap') return {...st, moves: st.moves.map(m=>m.ex===oldKey? (pl.blocks.flatMap(b=>b.steps).find(s=>s.t==='amrap' && s.moves.some(mm=>mm.ex===newKey))?.moves.find(mm=>mm.ex===newKey) || {...m, ex:newKey}) : m)};
      return st;
    });
  }
  save(); closeSheet();
  if(player && P){ renderPlayer(); coach.say(`Swapped. ${BY_KEY[newKey].n}`, true); } else renderToday();
}

// streak = consecutive days with a workout, ending today or yesterday
function streak(){
  const days = new Set(S.history.map(h=>h.date)); let n=0; const d=new Date();
  if(!days.has(todayStr())) d.setDate(d.getDate()-1);
  while(true){ const k=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; if(days.has(k)){ n++; d.setDate(d.getDate()-1);} else break; }
  return n;
}

function renderProgress(){
  const el=$('#view-progress'); const ph=phaseFor(S); const H=S.history;
  const totalMin = mins(H.reduce((a,h)=>a+(h.dur||0),0));
  const weekAgo = Date.now()-7*864e5; const wk = H.filter(h=>h.ts>=weekAgo);
  const groups = {Push:['hpush','vpush','tri'], Pull:['hpull','vpull','bi'], Legs:['squat','lunge'], Hips:['hinge','glute'], Core:['coreA','coreR','coreL','coreF'], Cardio:['cardio']};
  const gc = Object.fromEntries(Object.entries(groups).map(([g,ps])=>[g, wk.reduce((a,h)=>a+ps.reduce((x,p)=>x+((h.pat||{})[p]||0),0),0)]));
  const gmax = Math.max(1,...Object.values(gc));
  const targets = nextTargets(S);
  // last 28 days calendar
  const counts={}; H.forEach(h=>counts[h.date]=(counts[h.date]||0)+1);
  const cal=[]; for(let i=27;i>=0;i--){ const d=new Date(); d.setDate(d.getDate()-i); const k=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; cal.push(`<span class="${counts[k]>1?'two':counts[k]?'on':''}">${d.getDate()}</span>`); }
  const fbIcon = {easy:'Too easy', ok:'Just right', hard:'Too hard', hurt:'Hurt'};
  el.innerHTML = `
    <h1 style="font-size:28px">Progress</h1>
    <div class="card"><div class="spread"><div><div class="eyebrow">Month ${S.block.n} goal</div><h2 style="font-size:22px;margin-top:4px">${S.block.done} of ${S.block.goal} workouts</h2><div class="muted small">Week ${ph.week} of 4 · ${ph.name} · counts workouts, not days</div></div>${ring(S.block.done,S.block.goal,72)}</div>
      ${targets?`<div class="label" style="margin-top:14px">Month targets</div><div class="muted">${targets.map(esc).join(' · ')}</div>`:''}
      <div style="margin-top:12px"><button class="btn" id="ci">Month check-in</button></div></div>
    <div class="stats">
      <div class="stat"><b>${H.length}</b><span class="muted small">Workouts</span></div>
      <div class="stat"><b>${totalMin}</b><span class="muted small">Minutes</span></div>
      <div class="stat"><b>${streak()}</b><span class="muted small">Day streak</span></div>
      <div class="stat"><b>${wk.length}</b><span class="muted small">This week</span></div>
    </div>
    <div class="card"><div class="eyebrow">Muscle balance · last 7 days</div><div class="bars">${Object.entries(gc).map(([g,n])=>`<div class="b"><span>${g}</span><div class="track"><div class="fill" style="width:${n/gmax*100}%"></div></div><span class="muted small">${n}</span></div>`).join('')}</div><div class="muted small">Moves per area. The app keeps push and pull balanced and fills gaps automatically.</div></div>
    <div class="card"><div class="eyebrow">Last 4 weeks</div><div class="cal">${cal.join('')}</div></div>
    <div class="card"><div class="eyebrow">History</div><ul class="hist">${H.slice().reverse().slice(0,60).map(h=>`<li><div style="flex:1"><b>${esc(h.title)}</b><div class="muted small">${h.date} · ${mins(h.dur)} min · ${esc(h.fmtName||'')}${h.gym?' · Gym':''}</div></div><span class="pill ${h.feedback==='hard'?'hard':h.feedback==='easy'?'light':''}">${fbIcon[h.feedback]||'—'}</span></li>`).join('') || '<li class="muted">No workouts yet. Your first one is waiting on the Today tab.</li>'}</ul></div>`;
  $('#ci').onclick=openCheckin;
}

const MIXLBL = [['off','Off'],['little','A little'],['balanced','Balanced'],['focus','Focus']];
function mixRow(obj, key, label){
  return `<div class="set"><div class="spread"><span>${label}</span></div><div class="seg" style="margin-top:8px" data-mix="${key}">${MIXLBL.map(([v,l])=>`<button data-v="${v}" class="${obj[key]===v?'on':''}">${l}</button>`).join('')}</div></div>`;
}
function weightRow(arr, id){
  const opts=[1,2,3,4,5,6,7,8,10,12,14,16];
  return `<div class="chips" id="${id}" style="flex-wrap:wrap">${opts.map(w=>`<button class="chip ${arr.includes(w)?'on':''}" data-v="${w}">${w} kg</button>`).join('')}</div>`;
}
function renderSettings(){
  const el=$('#view-settings'); const s=S.settings;
  const voices = Coach.voices();
  el.innerHTML = `
    <h1 style="font-size:28px">Settings</h1>
    <div class="card"><div class="eyebrow">Home equipment · mix-in</div>
      <div class="muted small" style="margin-top:6px">"A little" = 2–3 easy moves, the rest bodyweight. "Focus" = about half the moves.</div>
      <div data-scope="mix">${mixRow(s.mix,'d','Dumbbells')}${mixRow(s.mix,'p','Pull-up bar')}${mixRow(s.mix,'r','Resistance bands')}</div>
      <div class="set"><span style="font-weight:550">Dumbbells I own</span>${weightRow(s.dbWeights,'w-home')}</div>
    </div>
    <div class="card"><div class="eyebrow">Extreme Gym · mix-in</div>
      <div data-scope="gymMix">${mixRow(s.gymMix,'g','Machines & cables')}${mixRow(s.gymMix,'d','Dumbbells')}${mixRow(s.gymMix,'p','Pull-up bar')}</div>
      <div class="set"><span style="font-weight:550">Gym dumbbells to use</span>${weightRow(s.gymWeights,'w-gym')}</div>
    </div>
    <div class="card"><div class="eyebrow">Workout</div>
      <div class="set spread"><span>Warm-up</span><select id="warm">${[4,5,6,8,10].map(v=>`<option ${s.warmMin===v?'selected':''} value="${v}">${v} min</option>`).join('')}</select></div>
      <div class="set spread"><span>Stretch / yoga</span><select id="str">${[5,7,9,12,15].map(v=>`<option ${s.stretchMin===v?'selected':''} value="${v}">${v} min</option>`).join('')}</select></div>
      <div class="set spread"><span>Monthly goal</span><select id="goal">${[16,20,24,28,32].map(v=>`<option ${S.block.goal===v?'selected':''} value="${v}">${v} workouts</option>`).join('')}</select></div>
      <div class="set spread"><div><span>Neck &amp; back care</span><div class="muted small">No neck-strain moves or deep spine stretches, capped back load, spine-prep warm-up</div></div><button class="toggle ${s.backCare?'on':''}" data-t="backCare"></button></div>
      <div class="set spread"><div><span>Quiet mode</span><div class="muted small">No jumping (neighbours, early mornings)</div></div><button class="toggle ${s.quiet?'on':''}" data-t="quiet"></button></div>
    </div>
    <div class="card"><div class="eyebrow">Voice coach</div>
      <div class="set spread"><span>Voice cues</span><button class="toggle ${s.voice?'on':''}" data-t="voice"></button></div>
      <div class="set spread"><span>Beeps</span><button class="toggle ${s.beeps?'on':''}" data-t="beeps"></button></div>
      <div class="set spread"><span>Voice</span><select id="vname"><option value="">Automatic</option>${voices.map(v=>`<option ${s.voiceName===v.name?'selected':''}>${esc(v.name)}</option>`).join('')}</select></div>
      <div class="set"><div class="spread"><span>With Spotify</span></div><div class="seg" id="amode" style="margin-top:8px"><button data-v="ambient" class="${s.audioMode==='ambient'?'on':''}">Mix over music</button><button data-v="transient" class="${s.audioMode==='transient'?'on':''}">Lower music</button></div><div class="muted small" style="margin-top:6px">On iPhone, "Mix" keeps Spotify at full volume; turn the ring/silent switch ON so beeps play.</div></div>
      <div class="set"><button class="btn primary" id="test">Play sound test</button></div>
    </div>
    <div class="card"><div class="eyebrow">Exercises I skip</div>
      ${(s.blocked||[]).length ? (s.blocked).map(k=>`<div class="set spread"><span>${esc(BY_KEY[k]?.n||k)}</span><button class="btn" data-unblock="${k}">Bring back</button></div>`).join('') : '<div class="muted small" style="margin-top:6px">None yet. Tap an exercise → "Don\'t show me this again" to add one.</div>'}
    </div>
    <div class="card"><div class="eyebrow">Look</div>
      <div class="seg" id="theme" style="margin-top:8px">${[['auto','Auto'],['light','Light'],['dark','Dark']].map(([v,l])=>`<button data-v="${v}" class="${s.theme===v?'on':''}">${l}</button>`).join('')}</div>
    </div>
    <div class="card"><div class="eyebrow">My levels (auto-adjusted)</div>
      <div class="muted small" style="margin:6px 0 4px">1 = beginner, 5 = advanced. Changed by your feedback and monthly check-in.</div>
      <div class="bars">${['hpush','vpush','hpull','vpull','squat','lunge','hinge','glute','coreA','cardio'].map(p=>`<div class="b"><span>${PATTERN_LABEL[p]}</span><div class="track"><div class="fill" style="width:${S.levels[p]/5*100}%"></div></div><span class="muted small">${(+S.levels[p]).toFixed(1)}</span></div>`).join('')}</div>
    </div>
    <div class="card"><div class="eyebrow">Data (stored only on this phone)</div>
      <div class="row" style="margin-top:10px;flex-wrap:wrap"><button class="btn" id="exp">Export backup</button><label class="btn">Import backup<input type="file" id="imp" accept="application/json" hidden></label></div>
      <div class="muted small" style="margin-top:10px">Version ${VERSION}</div>
    </div>`;
  el.querySelectorAll('[data-scope]').forEach(sc=>sc.onclick=e=>{ const b=e.target.closest('button'); const seg=e.target.closest('[data-mix]'); if(!b||!seg) return; S.settings[sc.dataset.scope][seg.dataset.mix]=b.dataset.v; save(); renderSettings(); });
  const wt=(id,arr)=>{ $('#'+id).onclick=e=>{ const v=+e.target.dataset.v; if(!v) return; const i=arr.indexOf(v); i>=0?arr.splice(i,1):arr.push(v); arr.sort((a,b)=>a-b); save(); renderSettings(); }; };
  wt('w-home', s.dbWeights); wt('w-gym', s.gymWeights);
  $('#warm').onchange=e=>{s.warmMin=+e.target.value;save();};
  $('#str').onchange=e=>{s.stretchMin=+e.target.value;save();};
  $('#goal').onchange=e=>{S.block.goal=+e.target.value;save();};
  $('#vname').onchange=e=>{s.voiceName=e.target.value;save();};
  el.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{ s[b.dataset.t]=!s[b.dataset.t]; save(); renderSettings(); });
  $('#amode').onclick=e=>{ const v=e.target.dataset.v; if(v){ s.audioMode=v; save(); renderSettings(); } };
  $('#theme').onclick=e=>{ const v=e.target.dataset.v; if(v){ s.theme=v; save(); applyTheme(); renderSettings(); } };
  el.querySelectorAll('[data-unblock]').forEach(b=>b.onclick=()=>{ s.blocked=s.blocked.filter(k=>k!==b.dataset.unblock); S.current=null; save(); renderSettings(); });
  $('#test').onclick=()=>{ coach.unlock(); coach.test(); };
  $('#exp').onclick=()=>{ const blob=new Blob([JSON.stringify(S,null,1)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=`move-backup-${todayStr()}.json`; a.click(); };
  $('#imp').onchange=async e=>{ const f=e.target.files[0]; if(!f) return; try{ const d=JSON.parse(await f.text()); if(!d.settings||!d.history) throw 0; S=deepMerge(structuredClone(DEFAULT), d); save(); renderSettings(); toastSheet('Backup restored.'); }catch(err){ toastSheet('That file is not a Move backup.'); } };
}

// ---------------- sheets ----------------
function openSheet(html){ const sh=$('#sheet'); sh.innerHTML=`<div class="panel">${html}</div>`; sh.hidden=false; sh.onclick=e=>{ if(e.target===sh) closeSheet(); }; return sh; }
function closeSheet(){ $('#sheet').hidden=true; $('#sheet').innerHTML=''; if(P && !$('#player').hidden && P.tl[P.i]?.t==='work') mountMedia($('#p-media'), BY_KEY[P.tl[P.i].ex], P.tl[P.i].side); }
function toastSheet(msg){ openSheet(`<h2>${esc(msg)}</h2><div class="fb"><button id="okb">OK</button></div>`); $('#okb').onclick=closeSheet; }

function openCheckin(){
  const last = S.checkins[S.checkins.length-1]||{};
  const f = (id,label,unit,val)=>`<div class="field"><span>${label}<br><span class="muted small">${unit}</span></span><input id="${id}" type="number" inputmode="numeric" min="0" value="${val??''}"></div>`;
  openSheet(`<h2>Month check-in</h2><div class="muted">Test each one fresh, with good form. Your next month is built from these.</div>
    <div style="margin-top:10px">${f('c-pu','Full push-ups','max reps',last.pushups)}${f('c-kpu','Knee push-ups','max reps',last.kneePushups)}${f('c-pl','Strict pull-ups','max reps',last.pullups)}${f('c-pk','Plank','seconds',last.plank)}${f('c-hg','Dead hang','seconds',last.hang)}</div>
    <div class="fb"><button id="c-save" style="background:var(--accent);color:var(--on-accent)">Save${S.block.done>=S.block.goal?' and start next month':''}</button><button id="c-cancel">Cancel</button></div>`);
  $('#c-cancel').onclick=closeSheet;
  $('#c-save').onclick=()=>{
    applyCheckin(S,{pushups:$('#c-pu').value,kneePushups:$('#c-kpu').value,pullups:$('#c-pl').value,plank:$('#c-pk').value,hang:$('#c-hg').value});
    if(S.block.done>=S.block.goal){ S.block={n:S.block.n+1, start:todayStr(), done:0, goal:S.block.goal}; S.effort=0; }
    S.current=null; save(); closeSheet(); show('today');
  };
}

// ---------------- player ----------------
const coach = new Coach(()=>S.settings);
let P = null; // player state

function buildTimeline(p){
  const tl=[];
  p.blocks.forEach((b,bi)=>{
    const first = b.steps.find(s=>s.t==='work'||s.t==='amrap');
    const firstName = first ? (first.t==='amrap' ? 'AMRAP' : BY_KEY[first.ex].n) : '';
    const care = S.settings.backCare && b.kind==='stretch' ? ' Stretch gently, stop at mild tension.' : '';
    const ramp = b.kind==='circuit' ? ' First round is a lighter ramp-up.' : '';
    tl.push({t:'prep', dur: bi===0?10:15, block:bi, blockName:b.name, say: (bi===0 ? `Get ready. ${b.name}.` : `${b.name}.`) + care + ramp + ` First up: ${firstName}`, next:first});
    b.steps.forEach((s,i)=>{
      const prev = b.steps[i-1];
      // transitions between back-to-back moves (warm-up, stretch) and side switches
      if(i>0 && s.t==='work' && prev && prev.t==='work'){
        if(s.switch && prev.ex===s.ex) tl.push({t:'rest', dur:5, block:bi, blockName:b.name, switchSides:true, next:s});
        else tl.push({t:'rest', dur: b.kind==='stretch'||b.kind==='flow'?8:5, block:bi, blockName:b.name, next:s, transition:true});
      }
      if(s.t==='rest'){ const nx=b.steps.slice(i+1).find(x=>x.t==='work'); tl.push({...s, block:bi, blockName:b.name, next:nx}); }
      else tl.push({...s, block:bi, blockName:b.name, kind:b.kind});
    });
  });
  return tl;
}

async function wake(on){
  try{
    if(on && 'wakeLock' in navigator){ P.lock = await navigator.wakeLock.request('screen'); }
    else if(!on && P?.lock){ await P.lock.release(); P.lock=null; }
  }catch(e){ console.warn('wakeLock', e); }
}
document.addEventListener('visibilitychange', ()=>{ if(P && !P.paused && document.visibilityState==='visible') wake(true); });

function startWorkout(p){
  coach.unlock();
  const tl = buildTimeline(p);
  P = {plan:p, tl, i:0, paused:false, endAt:0, left:0, fired:new Set(), rounds:0, startTs:Date.now(), active:0, lastTick:Date.now(), lock:null};
  $('#player').hidden=false; document.body.style.overflow='hidden';
  wake(true);
  enterStep(0);
  P.timer = setInterval(tick, 200);
}

function stepLabel(st){
  const ex = st.ex && BY_KEY[st.ex];
  return ex ? ex.n : '';
}
function sayNext(nx){ if(!nx) return ''; if(nx.t==='amrap') return 'AMRAP'; const ex=BY_KEY[nx.ex]; return ex?ex.n+(nx.side==='L'?', left side':''):''; }

function enterStep(i){
  if(i>=P.tl.length) return finishWorkout(true);
  P.i=i; const st=P.tl[i]; P.left=st.dur; P.endAt=Date.now()+st.dur*1000; P.fired=new Set(); P.rounds=0;
  renderPlayer();
  // entry cues
  if(st.t==='prep') coach.say(st.say, true);
  else if(st.t==='work'){
    const prev=P.tl[i-1];
    const counted = prev && (prev.t==='rest'||prev.t==='prep');
    if(counted){ coach.go(); }
    else coach.say(stepLabel(st), true);
    if(st.side==='R' && !counted) coach.say('Switch sides');
  }
  else if(st.t==='rest'){
    if(st.switchSides) coach.say('Switch sides', true);
    else if(st.transition) coach.say(`Next up: ${sayNext(st.next)}`, true);
    else if(st.tabata) coach.say(`Rest. Next: ${sayNext(st.next)}`, true);
    else coach.say(`${st.label? st.label+'. ':''}Rest ${st.dur} seconds. Next up: ${sayNext(st.next)}`, true);
    coach.restBeep();
  }
  else if(st.t==='amrap'){ coach.go(); }
}

function tick(){
  if(!P || P.paused) return;
  const now=Date.now(); P.active += (now-P.lastTick)/1000; P.lastTick=now;
  const st=P.tl[P.i]; const left=Math.max(0, Math.ceil((P.endAt-now)/1000));
  if(left!==P.left){ P.left=left; updateTimer(); }
  const once=(k,fn)=>{ if(!P.fired.has(k)){ P.fired.add(k); fn(); } };
  if(st.t==='prep'||st.t==='rest'){
    if(left<=3 && left>=1 && st.dur>=5) once('c'+left, ()=>coach.count(left));
  } else if(st.t==='work'){
    const short = st.dur<30;
    if(!short && left===Math.floor(st.dur/2) && st.dur>=30) once('half', ()=>coach.say('Halfway'));
    if(!short && left===5) once('l5', ()=>coach.say('Last 5 seconds'));
    if(short && left<=3 && left>=1) once('b'+left, ()=>coach.tick());
  } else if(st.t==='amrap'){
    if(left===Math.floor(st.dur/2)) once('half', ()=>coach.say('Halfway'));
    if(left===60 && st.dur>120) once('m1', ()=>coach.say('One minute left'));
    if(left===5) once('l5', ()=>coach.say('Last 5 seconds'));
  }
  if(now>=P.endAt){
    if(st.t==='work' || st.t==='amrap'){ coach.endBeep(); if(st.t==='amrap') coach.say(`Time! ${P.rounds} rounds.`, true); }
    enterStep(P.i+1);
  }
}

function fmtT(s){ return s>=60 ? `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}` : String(s); }
function updateTimer(){ const n=$('#p-num'); if(n) n.textContent=fmtT(P.left); }

function renderPlayer(){
  const el=$('#player'); const st=P.tl[P.i]; const p=P.plan;
  const done = P.tl.slice(0,P.i).reduce((a,x)=>a+x.dur,0), total=P.tl.reduce((a,x)=>a+x.dur,0);
  const isRest = st.t==='rest'||st.t==='prep';
  el.className = 'overlay' + (isRest?' is-rest':'');
  const curKind = p.blocks[st.block]?.kind; const skipBlk = ['warmup','stretch','flow'].includes(curKind) ? `<button class="skipblk" id="p-skipblk">Skip ${curKind==='warmup'?'warm-up':'stretch'} ›</button>` : '';
  const top = `<div class="p-top"><button class="x" id="p-x" aria-label="End">✕</button><div class="blk"><b>${esc(st.blockName)}</b><div class="prog"><i style="width:${done/total*100}%"></i></div></div><span class="muted small" style="font-variant-numeric:tabular-nums">${Math.max(1,Math.round((total-done)/60))} min left</span></div>`;
  const ctrl = `<div class="p-ctrl"><button id="p-back">Back</button><button class="pp" id="p-pp">${P.paused?'Resume':'Pause'}</button><button id="p-skip">Skip</button></div>`;
  let body='';
  if(st.t==='amrap'){
    body = `<div class="p-name" style="margin-top:14px">AMRAP</div><div class="p-cue">As many rounds as you can. Tap after each round.</div>
      <ul class="amrap-list">${st.moves.map(m=>{const x=BY_KEY[m.ex]; return `<li data-ex="${m.ex}"><span>${esc(x.n)} <span class="chev">›</span></span><span class="muted">${m.hold?'20 s':m.reps+'×'}${m.weight?` · ${m.weight} kg`:''}</span></li>`;}).join('')}</ul>
      <div class="p-timer amrap"><div class="num" id="p-num">${fmtT(P.left)}</div><div class="sub" id="p-rounds">${P.rounds} rounds</div></div>
      <button class="round-btn" id="p-round">+1 round</button>`;
  } else if(isRest){
    const nx = st.next; const nex = nx && nx.ex && BY_KEY[nx.ex];
    const title = st.t==='prep' ? 'Get ready' : st.switchSides ? 'Switch sides' : st.transition ? 'Get set' : 'Rest';
    body = `<div class="p-timer"><div class="sub">${title}</div><div class="num" id="p-num">${fmtT(P.left)}</div>${st.label?`<div class="sub">${esc(st.label)}</div>`:''}</div>
      ${nx ? `<div class="p-next">${nex?`<span class="th" ${thumb(nex)}></span>`:''}<div><div class="eyebrow">Next up</div><b style="font-size:19px">${nex?esc(nex.n):'AMRAP'}</b>${nx.side?` <span class="pill rest">${nx.side==='L'?'Left':'Right'}</span>`:''}<div class="muted small">${nex?esc(nex.c):''}</div></div></div>`:''}
      <div style="height:12px"></div>`;
  } else {
    const ex=BY_KEY[st.ex];
    const meta = [st.ramp?`<span class="pill light">Ramp-up · go lighter</span>`:'', st.set?`<span class="pill">${esc(st.set)}</span>`:'', (st.reps && st.dur>20)?`<span class="pill">~${st.reps} reps</span>`:(st.dur<=20?`<span class="pill">As many as you can</span>`:''), ex.f.includes('H')?`<span class="pill">Hold</span>`:'', st.weight?`<span class="pill hard">${st.weight} kg</span>`:''].join('');
    body = `<div class="media" id="p-media"></div><div class="spread" style="align-items:flex-start"><div class="p-name">${esc(ex.n)}</div><button class="swapbtn" id="p-swap">Swap</button></div>${meta?`<div class="p-meta">${meta}</div>`:''}<div class="p-cue">${esc(ex.c)}</div>
      <div class="p-timer"><div class="num" id="p-num">${fmtT(P.left)}</div></div>`;
  }
  el.innerHTML = top + (skipBlk?`<div style="text-align:right;margin-top:8px">${skipBlk}</div>`:'') + body + ctrl;
  if(st.t==='work') mountMedia($('#p-media'), BY_KEY[st.ex], st.side); else clearInterval(loopTimer);
  $('#p-x').onclick = askEnd;
  const sb=$('#p-skipblk'); if(sb) sb.onclick=()=>{ coach.stop(); const bi=st.block; let j=P.i; while(j<P.tl.length && P.tl[j].block===bi) j++; enterStep(j); };
  $('#p-pp').onclick = togglePause;
  $('#p-skip').onclick = ()=>{ coach.stop(); enterStep(P.i+1); };
  $('#p-back').onclick = ()=>{ coach.stop(); let j=P.i-1; while(j>0 && P.tl[j].t!=='work' && P.tl[j].t!=='amrap') j--; enterStep(Math.max(0,j)); };
  const openCur = ()=>{ if(!P.paused) togglePause(); openExercise(st.ex, {plan:P.plan, player:true}); };
  const sw=$('#p-swap'); if(sw) sw.onclick=openCur;
  const pm=$('#p-media'); if(pm) pm.onclick=openCur;
  el.querySelectorAll('.amrap-list li[data-ex]').forEach(li=>li.onclick=()=>{ if(!P.paused) togglePause(); openExercise(li.dataset.ex, {plan:P.plan, player:true}); });
  const rb=$('#p-round'); if(rb) rb.onclick=()=>{ P.rounds++; $('#p-rounds').textContent=`${P.rounds} round${P.rounds===1?'':'s'}`; coach.tick(); };
  const num=$('#p-num'); if(num) num.onclick=togglePause;
}
function togglePause(){
  if(P.paused){ P.paused=false; P.endAt=Date.now()+P.left*1000; P.lastTick=Date.now(); wake(true); coach.say('Go', true); }
  else { P.paused=true; P.left=Math.max(0,Math.ceil((P.endAt-Date.now())/1000)); coach.stop(); }
  const b=$('#p-pp'); if(b) b.textContent=P.paused?'Resume':'Pause';
}
function askEnd(){
  const wasPaused=P.paused; if(!wasPaused) togglePause();
  const pct = P.i/P.tl.length;
  openSheet(`<h2>End workout?</h2><div class="muted">You're ${Math.round(pct*100)}% through.${pct>=0.5?' It will still count toward your goal.':''}</div>
    <div class="fb">${pct>=0.5?'<button id="e-save">Finish and save</button>':''}<button id="e-quit">${pct>=0.5?'Quit without saving':'Quit'}</button><button id="e-cont" style="background:var(--accent);color:var(--on-accent)">Keep going</button></div>`);
  const s=$('#e-save'); if(s) s.onclick=()=>{ closeSheet(); finishWorkout(false); };
  $('#e-quit').onclick=()=>{ closeSheet(); stopPlayer(); };
  $('#e-cont').onclick=()=>{ closeSheet(); if(!wasPaused) togglePause(); };
}
function stopPlayer(){ clearInterval(P?.timer); clearInterval(loopTimer); coach.stop(); wake(false); $('#player').hidden=true; document.body.style.overflow=''; P=null; renderToday(); }

function finishWorkout(full){
  clearInterval(P.timer); clearInterval(loopTimer); wake(false);
  if(full) coach.say('Workout complete. Well done, Eve!', true);
  const p=P.plan; const dur=Math.round(P.active);
  const rec = {id:p.id, date:todayStr(), ts:Date.now(), dur, format:p.format, fmtName:p.fmtName, title:p.title, intensity:p.intensity, emphasis:p.emphasis, week:p.week, block:S.block.n, exs:p.exs, pat:p.pat, gym:!!p.gym, feedback:null, full};
  S.history.push(rec); S.block.done++; S.current=null; save();
  const el=$('#player'); el.className='overlay is-done';
  el.innerHTML = `<div class="done-wrap"><div class="eyebrow">Workout ${S.block.done} of ${S.block.goal} this month</div><h1>Nice work.</h1><div class="muted" style="margin-top:6px">${mins(dur)} minutes · ${p.exs.length} moves${p.gym?' · Sauna time 🙂':''}</div>
    <div class="fb" style="text-align:left"><div class="label">How did it feel?</div>
      <button data-f="easy">Too easy<small>Next sessions get harder variations, more work, less rest</small></button>
      <button data-f="ok">Just right<small>Keep progressing gently</small></button>
      <button data-f="hard">Too hard<small>Next sessions get easier variations and more rest</small></button>
      <button data-f="hurt" style="background:var(--warm-soft)">Something hurt<small>Next 3 sessions go light, back moves without weights</small></button></div></div>`;
  el.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{ rec.feedback=b.dataset.f; applyFeedback(S, p, b.dataset.f); save(); $('#player').hidden=true; document.body.style.overflow=''; P=null; show(S.block.done>=S.block.goal?'today':'progress'); });
}

// ---------------- boot ----------------
show('today');
if('serviceWorker' in navigator && location.protocol!=='file:'){
  const hadCtl = !!navigator.serviceWorker.controller;
  navigator.serviceWorker.register('sw.js').catch(e=>console.warn('sw', e));
  // a new version was published: reload once, but never mid-workout
  navigator.serviceWorker.addEventListener('controllerchange', ()=>{ if(hadCtl && !P) location.reload(); });
}
window.__move = { get state(){ return S; }, generate };
